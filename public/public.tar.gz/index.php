<?php
    require "src/includes/db.php";
?>
<?php
    require "src/includes/head.php";
?>
<body>
    <?php
        require "src/includes/header.php";
    ?>
    <div class="middle">
        
    </div>
    <?php
        require "src/includes/footer.php";
    ?>
</body>