<!DOCTYPE html>
<html>
<head>
    <!-- configuration -->
    <meta charset="UTF-8" />
    <title>CMS</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
    <meta name="robots" content="index.follow" />
    <!-- tailwind css -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" />
    <link rel="stylesheet" type="text/css" href="src/css/index.css"/>
</head>