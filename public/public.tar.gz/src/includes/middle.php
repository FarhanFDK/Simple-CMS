<div class="middle">
    <h1>HELLO</h1>
</div>